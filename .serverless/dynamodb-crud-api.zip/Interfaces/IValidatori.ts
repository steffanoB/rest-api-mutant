interface iValidator {
    
    isMutant(geneticCode:Array<string>): boolean 
   
}